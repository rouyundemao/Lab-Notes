from __future__ import annotations

import math
from typing import Dict, List, Tuple

from sqlalchemy.orm import Session

from app.models.column import ColumnType
from app.services.data import load_table_snapshot


def parse_number(value: str | None) -> float | None:
    if value is None:
        return None
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return None
    return parsed if math.isfinite(parsed) else None


def compute_boxplot(values: List[float]) -> Dict[str, float]:
    sorted_values = sorted(values)
    count = len(sorted_values)
    mid = count // 2
    median = (
        (sorted_values[mid - 1] + sorted_values[mid]) / 2
        if count % 2 == 0
        else sorted_values[mid]
    )
    lower = sorted_values[:mid]
    upper = sorted_values[mid + (0 if count % 2 == 0 else 1) :]

    def _median(values_list: List[float]) -> float:
        if not values_list:
            return sorted_values[0]
        m = len(values_list) // 2
        return (
            (values_list[m - 1] + values_list[m]) / 2
            if len(values_list) % 2 == 0
            else values_list[m]
        )

    q1 = _median(lower)
    q3 = _median(upper) if upper else sorted_values[-1]

    return {
        "min": sorted_values[0],
        "q1": q1,
        "median": median,
        "q3": q3,
        "max": sorted_values[-1],
    }


def compute_chart(
    db: Session,
    table_id: str,
    chart_type: str,
    x_column_id: str | None,
    y_column_ids: List[str],
    group_by_column_id: str | None,
) -> Dict[str, object]:
    columns, rows, cell_map = load_table_snapshot(db, table_id)
    column_lookup = {col.id: col for col in columns}

    def get_x_value(row_index: int, row_id: str) -> float | str | None:
        if not x_column_id or x_column_id not in column_lookup:
            return row_index + 1
        column = column_lookup[x_column_id]
        raw = cell_map.get((row_id, column.id))
        if column.type == ColumnType.numeric:
            return parse_number(raw)
        if column.type == ColumnType.index:
            return row_index + 1
        return raw or ""

    labels: List[str] = []
    datasets: List[Dict[str, object]] = []

    if chart_type == "boxPlot":
        if group_by_column_id and group_by_column_id in column_lookup:
            group_column = column_lookup[group_by_column_id]
            groups: Dict[str, Dict[str, List[Tuple[str, float]]]] = {}
            for row in rows:
                group_label = cell_map.get((row.id, group_column.id)) or "Ungrouped"
                groups.setdefault(group_label, {})
                for column_id in y_column_ids:
                    column = column_lookup.get(column_id)
                    if not column or column.type != ColumnType.numeric:
                        continue
                    value = parse_number(cell_map.get((row.id, column.id)))
                    if value is None:
                        continue
                    groups[group_label].setdefault(column_id, [])
                    groups[group_label][column_id].append((row.id, value))
            labels = list(groups.keys())
            for column_id in y_column_ids:
                column = column_lookup.get(column_id)
                if not column or column.type != ColumnType.numeric:
                    continue
                data = []
                row_ids = []
                for label in labels:
                    pairs = groups.get(label, {}).get(column_id, [])
                    values = [value for _, value in pairs]
                    data.append(compute_boxplot(values) if values else None)
                    row_ids.append([row_id for row_id, _ in pairs])
                datasets.append({
                    "label": column.name,
                    "data": data,
                    "row_ids": row_ids,
                })
        else:
            labels = [column_lookup[col_id].name for col_id in y_column_ids if col_id in column_lookup]
            values_sets = []
            rows_by_column = []
            for column_id in y_column_ids:
                column = column_lookup.get(column_id)
                if not column or column.type != ColumnType.numeric:
                    continue
                pairs = []
                for row in rows:
                    value = parse_number(cell_map.get((row.id, column.id)))
                    if value is None:
                        continue
                    pairs.append((row.id, value))
                values_sets.append([value for _, value in pairs])
                rows_by_column.append([row_id for row_id, _ in pairs])
            datasets.append({
                "label": "BoxPlot",
                "data": [compute_boxplot(values) if values else None for values in values_sets],
                "row_ids": rows_by_column,
            })
        return {
            "table_id": table_id,
            "chart_type": chart_type,
            "labels": labels,
            "datasets": datasets,
        }

    if chart_type in {"line", "multiLine", "scatter", "bar"}:
        for series_index, column_id in enumerate(y_column_ids):
            column = column_lookup.get(column_id)
            if not column or column.type != ColumnType.numeric:
                continue
            points = []
            for row_index, row in enumerate(rows):
                x_value = get_x_value(row_index, row.id)
                y_value = parse_number(cell_map.get((row.id, column.id)))
                if y_value is None or x_value is None:
                    continue
                points.append({"x": x_value, "y": y_value, "row_id": row.id})
            datasets.append({"label": column.name, "data": points})
        return {
            "table_id": table_id,
            "chart_type": chart_type,
            "labels": labels,
            "datasets": datasets,
        }

    if chart_type == "groupedBar" and group_by_column_id and group_by_column_id in column_lookup:
        group_column = column_lookup[group_by_column_id]
        groups: Dict[str, Dict[str, List[Tuple[str, float]]]] = {}
        for row in rows:
            group_label = cell_map.get((row.id, group_column.id)) or "Ungrouped"
            groups.setdefault(group_label, {})
            for column_id in y_column_ids:
                column = column_lookup.get(column_id)
                if not column or column.type != ColumnType.numeric:
                    continue
                value = parse_number(cell_map.get((row.id, column.id)))
                if value is None:
                    continue
                groups[group_label].setdefault(column_id, [])
                groups[group_label][column_id].append((row.id, value))
        labels = list(groups.keys())
        for column_id in y_column_ids:
            column = column_lookup.get(column_id)
            if not column or column.type != ColumnType.numeric:
                continue
            data = []
            row_ids = []
            for label in labels:
                pairs = groups.get(label, {}).get(column_id, [])
                values = [value for _, value in pairs]
                avg = sum(values) / len(values) if values else 0
                data.append(avg)
                row_ids.append([row_id for row_id, _ in pairs])
            datasets.append({"label": column.name, "data": data, "row_ids": row_ids})
        return {
            "table_id": table_id,
            "chart_type": chart_type,
            "labels": labels,
            "datasets": datasets,
        }

    return {
        "table_id": table_id,
        "chart_type": chart_type,
        "labels": [],
        "datasets": [],
    }
