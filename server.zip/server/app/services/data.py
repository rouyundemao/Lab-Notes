from typing import Dict, List, Tuple

from sqlalchemy.orm import Session

from app.models.column import ColumnType, TableColumn
from app.models.row import TableRow
from app.models.cell import TableCell


def load_table_snapshot(
    db: Session,
    table_id: str
) -> Tuple[List[TableColumn], List[TableRow], Dict[Tuple[str, str], str | None]]:
    columns = (
        db.query(TableColumn)
        .filter(TableColumn.table_id == table_id)
        .order_by(TableColumn.position)
        .all()
    )
    rows = (
        db.query(TableRow)
        .filter(TableRow.table_id == table_id)
        .order_by(TableRow.position)
        .all()
    )
    row_ids = [row.id for row in rows]
    cell_map: Dict[Tuple[str, str], str | None] = {}
    if row_ids:
        cells = db.query(TableCell).filter(TableCell.row_id.in_(row_ids)).all()
        cell_map = {(cell.row_id, cell.column_id): cell.value for cell in cells}
    return columns, rows, cell_map


def build_row_values(
    columns: List[TableColumn],
    row: TableRow,
    cell_map: Dict[Tuple[str, str], str | None]
) -> List[str | None]:
    values: List[str | None] = []
    for column in columns:
        values.append(cell_map.get((row.id, column.id)))
    return values


def sync_index_column(db: Session, table_id: str) -> None:
    columns = (
        db.query(TableColumn)
        .filter(TableColumn.table_id == table_id)
        .order_by(TableColumn.position)
        .all()
    )
    index_column = next((column for column in columns if column.type == ColumnType.index), None)
    if not index_column:
        return
    rows = (
        db.query(TableRow)
        .filter(TableRow.table_id == table_id)
        .order_by(TableRow.position)
        .all()
    )
    for idx, row in enumerate(rows, start=1):
        cell = (
            db.query(TableCell)
            .filter(TableCell.row_id == row.id, TableCell.column_id == index_column.id)
            .one_or_none()
        )
        if cell is None:
            cell = TableCell(row_id=row.id, column_id=index_column.id, value=str(idx))
            db.add(cell)
        else:
            cell.value = str(idx)
    db.flush()
