from __future__ import annotations

import math
from typing import Dict, List, Tuple

from sqlalchemy.orm import Session

from app.models.column import ColumnType, TableColumn
from app.services.data import load_table_snapshot


def parse_number(value: str | None) -> float | None:
    if value is None:
        return None
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return None
    return parsed if math.isfinite(parsed) else None


def compute_stats(values: List[float]) -> Dict[str, float]:
    sorted_values = sorted(values)
    count = len(sorted_values)
    average = sum(sorted_values) / count
    mid = count // 2
    median = (
        (sorted_values[mid - 1] + sorted_values[mid]) / 2
        if count % 2 == 0
        else sorted_values[mid]
    )
    variance = (
        sum((val - average) ** 2 for val in sorted_values) / (count - 1 if count > 1 else 1)
    )
    return {
        "count": count,
        "average": average,
        "median": median,
        "std": math.sqrt(variance),
        "min": sorted_values[0],
        "max": sorted_values[-1],
    }


def compute_analysis(
    db: Session,
    table_id: str,
    column_ids: List[str] | None = None,
    group_by_column_id: str | None = None,
    include_index: bool = False,
) -> Dict[str, object]:
    columns, rows, cell_map = load_table_snapshot(db, table_id)
    if column_ids:
        filtered = [col for col in columns if col.id in column_ids]
    else:
        filtered = columns

    results = []
    for column in filtered:
        if column.type == ColumnType.index and not include_index:
            continue
        row_ids: List[str] = []
        values: List[float] = []
        for row in rows:
            raw = cell_map.get((row.id, column.id))
            number = parse_number(raw)
            if number is None:
                continue
            row_ids.append(row.id)
            values.append(number)
        if column.type != ColumnType.numeric:
            results.append({
                "column": {
                    "id": column.id,
                    "name": column.name,
                    "type": column.type.value,
                    "unit": column.unit,
                },
                "stats": None,
                "row_ids": row_ids,
                "skipped": True,
            })
            continue
        if not values:
            results.append({
                "column": {
                    "id": column.id,
                    "name": column.name,
                    "type": column.type.value,
                    "unit": column.unit,
                },
                "stats": None,
                "row_ids": [],
                "skipped": True,
            })
            continue
        results.append({
            "column": {
                "id": column.id,
                "name": column.name,
                "type": column.type.value,
                "unit": column.unit,
            },
            "stats": compute_stats(values),
            "row_ids": row_ids,
            "skipped": False,
        })

    grouped: List[Dict[str, object]] = []
    if group_by_column_id:
        group_column = next((col for col in columns if col.id == group_by_column_id), None)
        if group_column and group_column.type == ColumnType.category:
            groups: Dict[str, Dict[str, List[Tuple[str, float]]]] = {}
            for row in rows:
                group_label = cell_map.get((row.id, group_column.id)) or "Ungrouped"
                groups.setdefault(group_label, {})
                for column in filtered:
                    if column.type != ColumnType.numeric:
                        continue
                    raw = cell_map.get((row.id, column.id))
                    number = parse_number(raw)
                    if number is None:
                        continue
                    groups[group_label].setdefault(column.id, [])
                    groups[group_label][column.id].append((row.id, number))
            for group_label, group_columns in groups.items():
                group_stats = []
                for column in filtered:
                    if column.type != ColumnType.numeric:
                        continue
                    pairs = group_columns.get(column.id, [])
                    if not pairs:
                        continue
                    row_ids = [row_id for row_id, _ in pairs]
                    values = [value for _, value in pairs]
                    group_stats.append({
                        "column": {
                            "id": column.id,
                            "name": column.name,
                            "type": column.type.value,
                            "unit": column.unit,
                        },
                        "stats": compute_stats(values),
                        "row_ids": row_ids,
                    })
                grouped.append({"group": group_label, "stats": group_stats})

    return {"table_id": table_id, "columns": results, "grouped": grouped}
