from sqlalchemy.orm import Session

from app.models.experiment import Experiment
from app.schemas.experiment import ExperimentCreate, ExperimentUpdate


def create_experiment(db: Session, payload: ExperimentCreate) -> Experiment:
    experiment = Experiment(name=payload.name, description=payload.description)
    db.add(experiment)
    db.commit()
    db.refresh(experiment)
    return experiment


def list_experiments(db: Session) -> list[Experiment]:
    return db.query(Experiment).order_by(Experiment.created_at.desc()).all()


def get_experiment(db: Session, experiment_id: str) -> Experiment | None:
    return db.query(Experiment).filter(Experiment.id == experiment_id).one_or_none()


def update_experiment(db: Session, experiment: Experiment, payload: ExperimentUpdate) -> Experiment:
    if payload.name is not None:
        experiment.name = payload.name
    if payload.description is not None:
        experiment.description = payload.description
    db.commit()
    db.refresh(experiment)
    return experiment


def delete_experiment(db: Session, experiment: Experiment) -> None:
    db.delete(experiment)
    db.commit()
