from sqlalchemy.orm import Session

from app.models.analysis import Analysis
from app.schemas.analysis import AnalysisCreate


def create_analysis(db: Session, experiment_id: str, payload: AnalysisCreate) -> Analysis:
    analysis = Analysis(
        experiment_id=experiment_id,
        table_id=payload.table_id,
        name=payload.name,
        config=payload.config
    )
    db.add(analysis)
    db.commit()
    db.refresh(analysis)
    return analysis


def get_analysis(db: Session, analysis_id: str) -> Analysis | None:
    return db.query(Analysis).filter(Analysis.id == analysis_id).one_or_none()


def list_analyses(db: Session, experiment_id: str) -> list[Analysis]:
    return (
        db.query(Analysis)
        .filter(Analysis.experiment_id == experiment_id)
        .order_by(Analysis.created_at.desc())
        .all()
    )


def delete_analysis(db: Session, analysis: Analysis) -> None:
    db.delete(analysis)
    db.commit()
