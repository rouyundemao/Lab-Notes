from sqlalchemy.orm import Session

from app.models.chart import Chart
from app.schemas.chart import ChartCreate


def create_chart(db: Session, experiment_id: str, payload: ChartCreate) -> Chart:
    chart = Chart(
        experiment_id=experiment_id,
        table_id=payload.table_id,
        name=payload.name,
        chart_type=payload.chart_type,
        x_column_id=payload.x_column_id,
        y_column_ids=payload.y_column_ids,
        group_by_column_id=payload.group_by_column_id,
        config=payload.config,
    )
    db.add(chart)
    db.commit()
    db.refresh(chart)
    return chart


def get_chart(db: Session, chart_id: str) -> Chart | None:
    return db.query(Chart).filter(Chart.id == chart_id).one_or_none()


def list_charts(db: Session, experiment_id: str) -> list[Chart]:
    return (
        db.query(Chart)
        .filter(Chart.experiment_id == experiment_id)
        .order_by(Chart.created_at.desc())
        .all()
    )


def delete_chart(db: Session, chart: Chart) -> None:
    db.delete(chart)
    db.commit()
