from sqlalchemy.orm import Session

from app.models.table import DataTable
from app.schemas.table import TableCreate, TableUpdate


def create_table(db: Session, experiment_id: str, payload: TableCreate) -> DataTable:
    table = DataTable(experiment_id=experiment_id, name=payload.name)
    db.add(table)
    db.commit()
    db.refresh(table)
    return table


def list_tables(db: Session, experiment_id: str) -> list[DataTable]:
    return (
        db.query(DataTable)
        .filter(DataTable.experiment_id == experiment_id)
        .order_by(DataTable.created_at.desc())
        .all()
    )


def get_table(db: Session, table_id: str) -> DataTable | None:
    return db.query(DataTable).filter(DataTable.id == table_id).one_or_none()


def update_table(db: Session, table: DataTable, payload: TableUpdate) -> DataTable:
    if payload.name is not None:
        table.name = payload.name
    db.commit()
    db.refresh(table)
    return table


def delete_table(db: Session, table: DataTable) -> None:
    db.delete(table)
    db.commit()
