from __future__ import annotations

import uuid
from datetime import datetime
from enum import Enum

from sqlalchemy import Boolean, DateTime, Enum as SqlEnum, ForeignKey, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base


class ColumnType(str, Enum):
    index = "index"
    numeric = "numeric"
    category = "category"


class TableColumn(Base):
    __tablename__ = "table_columns"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    table_id: Mapped[str] = mapped_column(ForeignKey("data_tables.id", ondelete="CASCADE"))
    name: Mapped[str] = mapped_column(String(200))
    type: Mapped[ColumnType] = mapped_column(SqlEnum(ColumnType), default=ColumnType.numeric)
    unit: Mapped[str | None] = mapped_column(String(50), nullable=True)
    visible: Mapped[bool] = mapped_column(Boolean, default=True)
    width: Mapped[int] = mapped_column(Integer, default=160)
    position: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now()
    )

    table: Mapped["DataTable"] = relationship("DataTable", back_populates="columns")
    cells: Mapped[list["TableCell"]] = relationship(
        "TableCell",
        back_populates="column",
        cascade="all, delete-orphan"
    )
