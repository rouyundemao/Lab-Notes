from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, String, Text, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base


class TableCell(Base):
    __tablename__ = "table_cells"
    __table_args__ = (UniqueConstraint("row_id", "column_id", name="uq_cell_row_column"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    row_id: Mapped[str] = mapped_column(ForeignKey("table_rows.id", ondelete="CASCADE"))
    column_id: Mapped[str] = mapped_column(ForeignKey("table_columns.id", ondelete="CASCADE"))
    value: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now()
    )

    row: Mapped["TableRow"] = relationship("TableRow", back_populates="cells")
    column: Mapped["TableColumn"] = relationship("TableColumn", back_populates="cells")
