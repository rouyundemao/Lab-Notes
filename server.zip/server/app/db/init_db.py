from app.db.base import Base
from app.db.session import engine
from app.models import (
    analysis,
    chart,
    cell,
    chart_config,
    column,
    column_schema,
    data_row,
    dataset,
    experiment,
    row,
    table,
)


def init_db() -> None:
    Base.metadata.create_all(bind=engine)
