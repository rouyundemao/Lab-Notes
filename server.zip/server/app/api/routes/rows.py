from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.models.cell import TableCell
from app.models.column import ColumnType, TableColumn
from app.models.row import TableRow
from app.schemas.row import RowCreate, RowOut, RowUpdate
from app.services.data import sync_index_column
from app.utils.response import success

router = APIRouter(tags=["rows"])


def shift_rows(db: Session, table_id: str, start: int, end: int, delta: int) -> None:
    rows = (
        db.query(TableRow)
        .filter(
            TableRow.table_id == table_id,
            TableRow.position >= start,
            TableRow.position <= end,
        )
        .order_by(TableRow.position.desc() if delta > 0 else TableRow.position.asc())
        .all()
    )
    for row in rows:
        row.position += delta


@router.post("/tables/{table_id}/rows")
def create_row_handler(
    table_id: str,
    payload: RowCreate,
    db: Session = Depends(get_db)
):
    columns = (
        db.query(TableColumn)
        .filter(TableColumn.table_id == table_id)
        .order_by(TableColumn.position)
        .all()
    )
    if not columns:
        raise HTTPException(status_code=404, detail="Table columns not found")

    max_position = (
        db.query(TableRow.position)
        .filter(TableRow.table_id == table_id)
        .order_by(TableRow.position.desc())
        .first()
    )
    next_position = max_position[0] + 1 if max_position else 0
    position = payload.position if payload.position is not None else next_position
    if position < 0:
        raise HTTPException(status_code=400, detail="Row position must be >= 0")

    if payload.position is not None and max_position is not None:
        max_pos = max_position[0]
        if position <= max_pos:
            shift_rows(db, table_id, position, max_pos, 1)

    row = TableRow(table_id=table_id, position=position)
    db.add(row)
    db.flush()

    values = payload.values or []
    for idx, column in enumerate(columns):
        if column.type == ColumnType.index:
            db.add(TableCell(row_id=row.id, column_id=column.id, value=str(position + 1)))
            continue
        value = values[idx] if idx < len(values) else ""
        db.add(TableCell(row_id=row.id, column_id=column.id, value=value))

    db.commit()
    sync_index_column(db, table_id)
    db.commit()
    return success(RowOut.model_validate(row).model_dump(), status_code=status.HTTP_201_CREATED)


@router.patch("/rows/{row_id}")
def update_row_handler(row_id: str, payload: RowUpdate, db: Session = Depends(get_db)):
    row = db.query(TableRow).filter(TableRow.id == row_id).one_or_none()
    if not row:
        raise HTTPException(status_code=404, detail="Row not found")

    if payload.position is not None and payload.position != row.position:
        target = payload.position
        if target < 0:
            raise HTTPException(status_code=400, detail="Row position must be >= 0")
        if target > row.position:
            shift_rows(db, row.table_id, row.position + 1, target, -1)
        else:
            shift_rows(db, row.table_id, target, row.position - 1, 1)
        row.position = target

    if payload.values is not None:
        columns = (
            db.query(TableColumn)
            .filter(TableColumn.table_id == row.table_id)
            .order_by(TableColumn.position)
            .all()
        )
        for idx, column in enumerate(columns):
            if column.type == ColumnType.index:
                continue
            if idx >= len(payload.values):
                continue
            cell = (
                db.query(TableCell)
                .filter(TableCell.row_id == row.id, TableCell.column_id == column.id)
                .one_or_none()
            )
            if cell is None:
                cell = TableCell(row_id=row.id, column_id=column.id, value=payload.values[idx])
                db.add(cell)
            else:
                cell.value = payload.values[idx]

    db.commit()
    sync_index_column(db, row.table_id)
    db.commit()
    return success(RowOut.model_validate(row).model_dump())


@router.delete("/rows/{row_id}")
def delete_row_handler(row_id: str, db: Session = Depends(get_db)):
    row = db.query(TableRow).filter(TableRow.id == row_id).one_or_none()
    if not row:
        raise HTTPException(status_code=404, detail="Row not found")
    table_id = row.table_id
    removed_position = row.position
    db.delete(row)
    db.commit()
    max_position = (
        db.query(TableRow.position)
        .filter(TableRow.table_id == table_id)
        .order_by(TableRow.position.desc())
        .first()
    )
    if max_position is not None:
        shift_rows(db, table_id, removed_position + 1, max_position[0], -1)
        db.commit()
    sync_index_column(db, table_id)
    db.commit()
    return success({"deleted": True})
