from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.crud.table import create_table, delete_table, get_table, list_tables, update_table
from app.models.cell import TableCell
from app.models.column import ColumnType, TableColumn
from app.models.row import TableRow
from app.schemas.table import TableCreate, TableDetail, TableOut, TableUpdate
from app.services.data import build_row_values, load_table_snapshot, sync_index_column
from app.utils.response import success

router = APIRouter(tags=["tables"])


def build_table_detail(db: Session, table_id: str) -> TableDetail:
    table = get_table(db, table_id)
    if not table:
        raise HTTPException(status_code=404, detail="Table not found")
    columns, rows, cell_map = load_table_snapshot(db, table_id)
    row_data = [
        {"id": row.id, "position": row.position, "values": build_row_values(columns, row, cell_map)}
        for row in rows
    ]
    return TableDetail(
        id=table.id,
        experiment_id=table.experiment_id,
        name=table.name,
        columns=columns,
        rows=row_data,
    )


@router.get("/experiments/{experiment_id}/tables")
def list_tables_handler(experiment_id: str, db: Session = Depends(get_db)):
    records = list_tables(db, experiment_id)
    data = [TableOut.model_validate(item).model_dump() for item in records]
    return success(data)


@router.post("/experiments/{experiment_id}/tables")
def create_table_handler(
    experiment_id: str,
    payload: TableCreate,
    db: Session = Depends(get_db)
):
    table = create_table(db, experiment_id, payload)

    index_column = TableColumn(
        table_id=table.id,
        name="Index",
        type=ColumnType.index,
        position=0,
        width=90,
    )
    value_column = TableColumn(
        table_id=table.id,
        name="Measure 1",
        type=ColumnType.numeric,
        position=1,
        width=160,
    )
    db.add_all([index_column, value_column])
    db.flush()

    rows = []
    cells = []
    for idx in range(3):
        row = TableRow(table_id=table.id, position=idx)
        db.add(row)
        db.flush()
        rows.append(row)
        cells.append(TableCell(row_id=row.id, column_id=index_column.id, value=str(idx + 1)))
        cells.append(TableCell(row_id=row.id, column_id=value_column.id, value=""))
    db.add_all(cells)
    db.commit()

    return success(build_table_detail(db, table.id).model_dump(), status_code=status.HTTP_201_CREATED)


@router.get("/tables/{table_id}")
def get_table_handler(table_id: str, db: Session = Depends(get_db)):
    detail = build_table_detail(db, table_id)
    return success(detail.model_dump())


@router.patch("/tables/{table_id}")
def update_table_handler(
    table_id: str,
    payload: TableUpdate,
    db: Session = Depends(get_db)
):
    table = get_table(db, table_id)
    if not table:
        raise HTTPException(status_code=404, detail="Table not found")
    updated = update_table(db, table, payload)
    return success(TableOut.model_validate(updated).model_dump())


@router.delete("/tables/{table_id}")
def delete_table_handler(table_id: str, db: Session = Depends(get_db)):
    table = get_table(db, table_id)
    if not table:
        raise HTTPException(status_code=404, detail="Table not found")
    delete_table(db, table)
    return success({"deleted": True})
