from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.crud.chart import create_chart, delete_chart, get_chart, list_charts
from app.crud.table import get_table
from app.schemas.chart import ChartComputeRequest, ChartCreate, ChartOut
from app.services.chart import compute_chart
from app.utils.response import success

router = APIRouter(tags=["charts"])


@router.get("/experiments/{experiment_id}/charts")
def list_charts_handler(experiment_id: str, db: Session = Depends(get_db)):
    records = list_charts(db, experiment_id)
    data = [ChartOut.model_validate(item).model_dump() for item in records]
    return success(data)


@router.post("/experiments/{experiment_id}/charts")
def create_chart_handler(
    experiment_id: str,
    payload: ChartCreate,
    db: Session = Depends(get_db)
):
    table = get_table(db, payload.table_id)
    if not table or table.experiment_id != experiment_id:
        raise HTTPException(status_code=400, detail="Table not found for experiment")
    record = create_chart(db, experiment_id, payload)
    return success(ChartOut.model_validate(record).model_dump(), status_code=status.HTTP_201_CREATED)


@router.get("/charts/{chart_id}")
def get_chart_handler(chart_id: str, db: Session = Depends(get_db)):
    record = get_chart(db, chart_id)
    if not record:
        raise HTTPException(status_code=404, detail="Chart not found")
    return success(ChartOut.model_validate(record).model_dump())


@router.delete("/charts/{chart_id}")
def delete_chart_handler(chart_id: str, db: Session = Depends(get_db)):
    record = get_chart(db, chart_id)
    if not record:
        raise HTTPException(status_code=404, detail="Chart not found")
    delete_chart(db, record)
    return success({"deleted": True})


@router.post("/charts/compute")
def compute_chart_handler(payload: ChartComputeRequest, db: Session = Depends(get_db)):
    table = get_table(db, payload.table_id)
    if not table:
        raise HTTPException(status_code=404, detail="Table not found")
    data = compute_chart(
        db,
        table_id=payload.table_id,
        chart_type=payload.chart_type,
        x_column_id=payload.x_column_id,
        y_column_ids=payload.y_column_ids,
        group_by_column_id=payload.group_by_column_id,
    )
    return success(data)
