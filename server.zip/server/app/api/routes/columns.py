from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.models.cell import TableCell
from app.models.column import ColumnType, TableColumn
from app.models.row import TableRow
from app.schemas.column import ColumnCreate, ColumnOut, ColumnUpdate
from app.services.data import sync_index_column
from app.utils.response import success

router = APIRouter(tags=["columns"])


@router.post("/tables/{table_id}/columns")
def create_column_handler(
    table_id: str,
    payload: ColumnCreate,
    db: Session = Depends(get_db)
):
    existing = (
        db.query(TableColumn)
        .filter(TableColumn.table_id == table_id)
        .order_by(TableColumn.position.desc())
        .all()
    )
    if payload.type == ColumnType.index and any(col.type == ColumnType.index for col in existing):
        raise HTTPException(status_code=400, detail="Index column already exists")
    position = existing[0].position + 1 if existing else 0
    column = TableColumn(
        table_id=table_id,
        name=payload.name,
        type=payload.type,
        unit=payload.unit,
        visible=payload.visible,
        width=payload.width,
        position=position,
    )
    db.add(column)
    db.flush()

    rows = db.query(TableRow).filter(TableRow.table_id == table_id).all()
    for row in rows:
        db.add(TableCell(row_id=row.id, column_id=column.id, value=""))

    db.commit()
    sync_index_column(db, table_id)
    db.commit()
    return success(ColumnOut.model_validate(column).model_dump(), status_code=status.HTTP_201_CREATED)


@router.patch("/columns/{column_id}")
def update_column_handler(
    column_id: str,
    payload: ColumnUpdate,
    db: Session = Depends(get_db)
):
    column = db.query(TableColumn).filter(TableColumn.id == column_id).one_or_none()
    if not column:
        raise HTTPException(status_code=404, detail="Column not found")
    if column.type == ColumnType.index and payload.type and payload.type != ColumnType.index:
        raise HTTPException(status_code=400, detail="Index column type cannot be changed")
    if payload.type == ColumnType.index:
        exists = (
            db.query(TableColumn)
            .filter(TableColumn.table_id == column.table_id, TableColumn.type == ColumnType.index)
            .first()
        )
        if exists and exists.id != column.id:
            raise HTTPException(status_code=400, detail="Index column already exists")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(column, field, value)
    db.commit()
    db.refresh(column)
    sync_index_column(db, column.table_id)
    db.commit()
    return success(ColumnOut.model_validate(column).model_dump())


@router.delete("/columns/{column_id}")
def delete_column_handler(column_id: str, db: Session = Depends(get_db)):
    column = db.query(TableColumn).filter(TableColumn.id == column_id).one_or_none()
    if not column:
        raise HTTPException(status_code=404, detail="Column not found")
    if column.type == ColumnType.index:
        raise HTTPException(status_code=400, detail="Index column cannot be deleted")
    table_id = column.table_id
    db.delete(column)
    db.commit()
    sync_index_column(db, table_id)
    db.commit()
    return success({"deleted": True})
