from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.crud.experiment import (
    create_experiment,
    delete_experiment,
    get_experiment,
    list_experiments,
    update_experiment,
)
from app.schemas.experiment import ExperimentCreate, ExperimentOut, ExperimentUpdate
from app.utils.response import success

router = APIRouter(prefix="/experiments", tags=["experiments"])


@router.get("")
def get_experiments(db: Session = Depends(get_db)):
    records = list_experiments(db)
    data = [ExperimentOut.model_validate(item).model_dump() for item in records]
    return success(data)


@router.post("")
def create_experiment_handler(payload: ExperimentCreate, db: Session = Depends(get_db)):
    record = create_experiment(db, payload)
    return success(ExperimentOut.model_validate(record).model_dump(), status_code=status.HTTP_201_CREATED)


@router.get("/{experiment_id}")
def get_experiment_handler(experiment_id: str, db: Session = Depends(get_db)):
    record = get_experiment(db, experiment_id)
    if not record:
        raise HTTPException(status_code=404, detail="Experiment not found")
    return success(ExperimentOut.model_validate(record).model_dump())


@router.patch("/{experiment_id}")
def update_experiment_handler(
    experiment_id: str,
    payload: ExperimentUpdate,
    db: Session = Depends(get_db)
):
    record = get_experiment(db, experiment_id)
    if not record:
        raise HTTPException(status_code=404, detail="Experiment not found")
    updated = update_experiment(db, record, payload)
    return success(ExperimentOut.model_validate(updated).model_dump())


@router.delete("/{experiment_id}")
def delete_experiment_handler(experiment_id: str, db: Session = Depends(get_db)):
    record = get_experiment(db, experiment_id)
    if not record:
        raise HTTPException(status_code=404, detail="Experiment not found")
    delete_experiment(db, record)
    return success({"deleted": True})
