from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.crud.analysis import create_analysis, delete_analysis, get_analysis, list_analyses
from app.crud.table import get_table
from app.schemas.analysis import AnalysisComputeRequest, AnalysisOut
from app.schemas.analysis import AnalysisCreate
from app.services.analysis import compute_analysis
from app.utils.response import success

router = APIRouter(tags=["analysis"])


@router.get("/experiments/{experiment_id}/analyses")
def list_analyses_handler(experiment_id: str, db: Session = Depends(get_db)):
    records = list_analyses(db, experiment_id)
    data = [AnalysisOut.model_validate(item).model_dump() for item in records]
    return success(data)


@router.post("/experiments/{experiment_id}/analyses")
def create_analysis_handler(
    experiment_id: str,
    payload: AnalysisCreate,
    db: Session = Depends(get_db)
):
    table = get_table(db, payload.table_id)
    if not table or table.experiment_id != experiment_id:
        raise HTTPException(status_code=400, detail="Table not found for experiment")
    record = create_analysis(db, experiment_id, payload)
    return success(AnalysisOut.model_validate(record).model_dump(), status_code=status.HTTP_201_CREATED)


@router.get("/analyses/{analysis_id}")
def get_analysis_handler(analysis_id: str, db: Session = Depends(get_db)):
    record = get_analysis(db, analysis_id)
    if not record:
        raise HTTPException(status_code=404, detail="Analysis not found")
    return success(AnalysisOut.model_validate(record).model_dump())


@router.delete("/analyses/{analysis_id}")
def delete_analysis_handler(analysis_id: str, db: Session = Depends(get_db)):
    record = get_analysis(db, analysis_id)
    if not record:
        raise HTTPException(status_code=404, detail="Analysis not found")
    delete_analysis(db, record)
    return success({"deleted": True})


@router.post("/analysis/compute")
def compute_analysis_handler(payload: AnalysisComputeRequest, db: Session = Depends(get_db)):
    table = get_table(db, payload.table_id)
    if not table:
        raise HTTPException(status_code=404, detail="Table not found")
    data = compute_analysis(
        db,
        table_id=payload.table_id,
        column_ids=payload.column_ids,
        group_by_column_id=payload.group_by_column_id,
        include_index=payload.include_index,
    )
    return success(data)
