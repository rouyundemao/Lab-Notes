from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.schemas.dataset import DatasetCreate, DatasetOut
from app.services.dataset import (
    create_dataset,
    delete_dataset,
    get_dataset,
    list_datasets,
    update_dataset,
)
from app.utils.response_v1 import ok

router = APIRouter(prefix="/datasets", tags=["datasets"])


@router.post("", status_code=status.HTTP_201_CREATED)
def create_dataset_handler(
    payload: DatasetCreate,
    request: Request,
    db: Session = Depends(get_db),
):
    record = create_dataset(db, payload)
    data = DatasetOut.model_validate(record).model_dump(by_alias=True)
    return ok(
        data,
        request,
        status_code=status.HTTP_201_CREATED,
        meta={"datasetVersion": record.version},
    )


@router.get("")
def list_datasets_handler(
    request: Request,
    db: Session = Depends(get_db),
    owner_id: str | None = Query(None, alias="ownerId"),
):
    records = list_datasets(db, owner_id)
    data = [DatasetOut.model_validate(item).model_dump(by_alias=True) for item in records]
    version = max((item.version for item in records), default=0)
    return ok(data, request, meta={"datasetVersion": version})


@router.get("/{dataset_id}")
def get_dataset_handler(dataset_id: str, request: Request, db: Session = Depends(get_db)):
    record = get_dataset(db, dataset_id)
    if not record:
        raise HTTPException(status_code=404, detail="Dataset not found")
    data = DatasetOut.model_validate(record).model_dump(by_alias=True)
    return ok(data, request, meta={"datasetVersion": record.version})


@router.put("/{dataset_id}")
def update_dataset_handler(
    dataset_id: str,
    payload: DatasetCreate,
    request: Request,
    db: Session = Depends(get_db),
):
    record = get_dataset(db, dataset_id)
    if not record:
        raise HTTPException(status_code=404, detail="Dataset not found")
    updated = update_dataset(db, record, payload)
    data = DatasetOut.model_validate(updated).model_dump(by_alias=True)
    return ok(data, request, meta={"datasetVersion": updated.version})


@router.delete("/{dataset_id}")
def delete_dataset_handler(dataset_id: str, request: Request, db: Session = Depends(get_db)):
    record = get_dataset(db, dataset_id)
    if not record:
        raise HTTPException(status_code=404, detail="Dataset not found")
    version = record.version
    delete_dataset(db, record)
    return ok({"deleted": True, "id": dataset_id}, request, meta={"datasetVersion": version})
