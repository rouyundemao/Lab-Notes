from fastapi import APIRouter

from app.api.routes.analysis import router as analysis_router
from app.api.routes.charts import router as charts_router
from app.api.routes.columns import router as columns_router
from app.api.routes.experiments import router as experiments_router
from app.api.routes.health import router as health_router
from app.api.routes.rows import router as rows_router
from app.api.routes.tables import router as tables_router

api_router = APIRouter()

api_router.include_router(health_router)
api_router.include_router(experiments_router)
api_router.include_router(tables_router)
api_router.include_router(columns_router)
api_router.include_router(rows_router)
api_router.include_router(analysis_router)
api_router.include_router(charts_router)
