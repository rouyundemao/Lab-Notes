from pydantic import BaseModel, ConfigDict

from app.models.column import ColumnType


class ColumnCreate(BaseModel):
    name: str
    type: ColumnType = ColumnType.numeric
    unit: str | None = None
    visible: bool = True
    width: int = 160


class ColumnUpdate(BaseModel):
    name: str | None = None
    type: ColumnType | None = None
    unit: str | None = None
    visible: bool | None = None
    width: int | None = None
    position: int | None = None


class ColumnOut(BaseModel):
    id: str
    table_id: str
    name: str
    type: ColumnType
    unit: str | None = None
    visible: bool
    width: int
    position: int

    model_config = ConfigDict(from_attributes=True)
