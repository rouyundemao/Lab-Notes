from typing import List

from pydantic import BaseModel, ConfigDict


class RowCreate(BaseModel):
    position: int | None = None
    values: List[str | None] | None = None


class RowUpdate(BaseModel):
    position: int | None = None
    values: List[str | None] | None = None


class RowOut(BaseModel):
    id: str
    table_id: str
    position: int

    model_config = ConfigDict(from_attributes=True)
