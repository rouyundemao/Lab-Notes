from datetime import datetime
from typing import List

from pydantic import BaseModel, ConfigDict

from app.models.column import ColumnType


class ColumnMeta(BaseModel):
    id: str
    name: str
    type: ColumnType
    unit: str | None = None
    visible: bool
    width: int
    position: int

    model_config = ConfigDict(from_attributes=True)


class RowData(BaseModel):
    id: str
    position: int
    values: List[str | None]


class TableCreate(BaseModel):
    name: str


class TableUpdate(BaseModel):
    name: str | None = None


class TableOut(BaseModel):
    id: str
    experiment_id: str
    name: str
    created_at: datetime
    updated_at: datetime | None = None

    model_config = ConfigDict(from_attributes=True)


class TableDetail(BaseModel):
    id: str
    experiment_id: str
    name: str
    columns: List[ColumnMeta]
    rows: List[RowData]

    model_config = ConfigDict(from_attributes=True)
