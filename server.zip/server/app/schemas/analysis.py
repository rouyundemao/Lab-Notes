from datetime import datetime
from typing import List

from pydantic import BaseModel, ConfigDict


class AnalysisCreate(BaseModel):
    table_id: str
    name: str
    config: dict = {}


class AnalysisOut(BaseModel):
    id: str
    experiment_id: str
    table_id: str
    name: str
    config: dict
    created_at: datetime
    updated_at: datetime | None = None

    model_config = ConfigDict(from_attributes=True)


class AnalysisComputeRequest(BaseModel):
    table_id: str
    column_ids: List[str] | None = None
    group_by_column_id: str | None = None
    include_index: bool = False


class AnalysisComputeResponse(BaseModel):
    table_id: str
    columns: list
    grouped: list
