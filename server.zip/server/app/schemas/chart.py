from datetime import datetime
from typing import List

from pydantic import BaseModel, ConfigDict


class ChartCreate(BaseModel):
    table_id: str
    name: str
    chart_type: str
    x_column_id: str | None = None
    y_column_ids: List[str] = []
    group_by_column_id: str | None = None
    config: dict = {}


class ChartOut(BaseModel):
    id: str
    experiment_id: str
    table_id: str
    name: str
    chart_type: str
    x_column_id: str | None = None
    y_column_ids: List[str]
    group_by_column_id: str | None = None
    config: dict
    created_at: datetime
    updated_at: datetime | None = None

    model_config = ConfigDict(from_attributes=True)


class ChartComputeRequest(BaseModel):
    table_id: str
    chart_type: str
    x_column_id: str | None = None
    y_column_ids: List[str] = []
    group_by_column_id: str | None = None


class ChartComputeResponse(BaseModel):
    table_id: str
    chart_type: str
    labels: list
    datasets: list
