from pydantic import BaseModel, ConfigDict


class CellUpdate(BaseModel):
    column_id: str
    value: str | None = None


class CellOut(BaseModel):
    id: str
    row_id: str
    column_id: str
    value: str | None = None

    model_config = ConfigDict(from_attributes=True)
