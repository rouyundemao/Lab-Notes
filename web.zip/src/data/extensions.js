export const extensionsCatalog = [
  {
    id: 'dataViz',
    titleKey: 'extensionDataViz',
    descKey: 'extensionDataVizDesc',
    blockType: 'chart'
  },
  {
    id: 'analysis',
    titleKey: 'extensionAnalysis',
    descKey: 'extensionAnalysisDesc',
    blockType: 'analysis'
  },
  {
    id: 'attachments',
    titleKey: 'extensionAttachments',
    descKey: 'extensionAttachmentsDesc',
    blockType: 'attachments'
  },
  {
    id: 'video',
    titleKey: 'extensionVideo',
    descKey: 'extensionVideoDesc',
    blockType: 'video'
  },
  {
    id: 'checklist',
    titleKey: 'extensionChecklist',
    descKey: 'extensionChecklistDesc',
    blockType: 'checklist'
  },
  {
    id: 'references',
    titleKey: 'extensionReferences',
    descKey: 'extensionReferencesDesc',
    blockType: 'references'
  }
];
