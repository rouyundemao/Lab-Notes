import { useEffect, useRef, useState } from 'react';
import { clampWidth, createColumn } from '../data/tables.js';

const ensureRowLength = (columns, rows) =>
  rows.map((row) => {
    const next = [...row];
    while (next.length < columns.length) {
      next.push('');
    }
    return next.slice(0, columns.length);
  });

const getIndexColumnIndex = (columns) =>
  Math.max(
    0,
    columns.findIndex((column) => column.type === 'index')
  );

export default function DataTable({ table, onChange, t }) {
  const [resizing, setResizing] = useState(null);
  const columnsRef = useRef(table.columns);
  const rowsRef = useRef(table.rows);

  const columns = table.columns || [];
  const rows = ensureRowLength(columns, table.rows || []);
  const indexColumnIndex = getIndexColumnIndex(columns);

  useEffect(() => {
    columnsRef.current = columns;
    rowsRef.current = rows;
  }, [columns, rows]);

  useEffect(() => {
    if (!columns.length) return;
    const nextColumns = columns.map((column) => ({
      ...column,
      width: clampWidth(column.type, column.width)
    }));
    const nextRows = rows.map((row, rowIndex) => {
      const next = [...row];
      next[indexColumnIndex] = String(rowIndex + 1);
      return next;
    });
    const widthChanged = nextColumns.some(
      (column, index) => column.width !== columns[index]?.width
    );
    const indexMismatch = rows.some(
      (row, rowIndex) => row[indexColumnIndex] !== String(rowIndex + 1)
    );
    if (widthChanged || indexMismatch) {
      onChange({ ...table, columns: nextColumns, rows: nextRows });
    }
  }, [columns, indexColumnIndex, onChange, rows, table]);

  useEffect(() => {
    if (!resizing) return;

    const handleMove = (event) => {
      const { index, startX, startWidth } = resizing;
      const nextWidth = clampWidth(
        columnsRef.current[index]?.type,
        startWidth + event.clientX - startX
      );
      const nextColumns = columnsRef.current.map((column, columnIndex) =>
        columnIndex === index ? { ...column, width: nextWidth } : column
      );
      onChange({ ...table, columns: nextColumns, rows: rowsRef.current });
    };

    const handleUp = () => setResizing(null);
    window.addEventListener('pointermove', handleMove);
    window.addEventListener('pointerup', handleUp);
    return () => {
      window.removeEventListener('pointermove', handleMove);
      window.removeEventListener('pointerup', handleUp);
    };
  }, [onChange, resizing, table]);

  const updateColumn = (index, patch) => {
    const nextColumns = columns.map((column, columnIndex) =>
      columnIndex === index ? { ...column, ...patch } : column
    );
    onChange({ ...table, columns: nextColumns, rows });
  };

  const updateCell = (rowIndex, colIndex, nextValue) => {
    if (colIndex === indexColumnIndex) return;
    const nextRows = rows.map((row, rIndex) => {
      if (rIndex !== rowIndex) return row;
      const nextRow = [...row];
      nextRow[colIndex] = nextValue;
      return nextRow;
    });
    onChange({ ...table, rows: nextRows });
  };

  const addRow = () => {
    const nextRows = [
      ...rows,
      columns.map((column, colIndex) =>
        colIndex === indexColumnIndex ? String(rows.length + 1) : ''
      )
    ];
    onChange({ ...table, rows: nextRows });
  };

  const removeRow = (rowIndex) => {
    if (rows.length <= 1) return;
    const nextRows = rows.filter((_, index) => index !== rowIndex);
    onChange({ ...table, rows: nextRows });
  };

  const addColumn = (type) => {
    const name =
      type === 'category'
        ? `${t('categoryColumn')} ${columns.length}`
        : `${t('numericColumn')} ${columns.length}`;
    const nextColumns = [
      ...columns,
      createColumn({ name, type, width: clampWidth(type) })
    ];
    const nextRows = rows.map((row) => [...row, '']);
    onChange({ ...table, columns: nextColumns, rows: nextRows });
  };

  const removeColumn = (colIndex) => {
    if (colIndex === indexColumnIndex) return;
    if (columns.length <= 2) return;
    const nextColumns = columns.filter((_, index) => index !== colIndex);
    const nextRows = rows.map((row) => row.filter((_, index) => index !== colIndex));
    onChange({ ...table, columns: nextColumns, rows: nextRows });
  };

  return (
    <div className="data-table">
      <div className="table-actions">
        <div className="table-meta">
          <span>
            {t('dataRows')} {rows.length}
          </span>
          <span>
            {t('dataColumns')} {columns.length}
          </span>
        </div>
        <div className="table-buttons">
          <button className="btn ghost" type="button" onClick={addRow}>
            {t('addRow')}
          </button>
          <button className="btn ghost" type="button" onClick={() => addColumn('numeric')}>
            {t('addNumericColumn')}
          </button>
          <button className="btn ghost" type="button" onClick={() => addColumn('category')}>
            {t('addCategoryColumn')}
          </button>
        </div>
      </div>
      <div className="table-scroll">
        <table className="data-grid">
          <thead>
            <tr>
              {columns.map((column, index) => (
                <th
                  key={column.id}
                  className={index === indexColumnIndex ? 'sticky-col sticky-head' : undefined}
                  style={{ width: column.width }}
                >
                  <div className="th-content">
                    {column.type === 'index' ? (
                      <span className="index-cell">{t('indexColumn')}</span>
                    ) : (
                      <input
                        type="text"
                        value={column.name}
                        onChange={(event) =>
                          updateColumn(index, { name: event.target.value })
                        }
                        title={column.name}
                      />
                    )}
                    <button
                      className="icon-btn"
                      type="button"
                      onClick={() => removeColumn(index)}
                      disabled={column.type === 'index' || columns.length <= 2}
                      aria-label={t('deleteColumn')}
                      title={t('deleteColumn')}
                    >
                      x
                    </button>
                  </div>
                  <div className="th-meta">
                    <span className="th-label">{t('columnType')}</span>
                    <select
                      value={column.type}
                      onChange={(event) =>
                        updateColumn(index, {
                          type: event.target.value,
                          width: clampWidth(event.target.value, column.width)
                        })
                      }
                      disabled={column.type === 'index'}
                    >
                      {column.type === 'index' ? (
                        <option value="index">{t('columnTypeIndex')}</option>
                      ) : (
                        <>
                          <option value="numeric">{t('columnTypeNumeric')}</option>
                          <option value="category">{t('columnTypeCategory')}</option>
                        </>
                      )}
                    </select>
                    <span className="th-label">{t('columnUnit')}</span>
                    <input
                      type="text"
                      value={column.unit || ''}
                      onChange={(event) => updateColumn(index, { unit: event.target.value })}
                      placeholder="-"
                      disabled={column.type === 'index'}
                    />
                  </div>
                  <div
                    className="col-resizer"
                    onPointerDown={(event) => {
                      event.preventDefault();
                      setResizing({
                        index,
                        startX: event.clientX,
                        startWidth: column.width || clampWidth(column.type)
                      });
                    }}
                  />
                </th>
              ))}
              <th className="action-col" aria-label={t('rowActions')} />
            </tr>
          </thead>
          <tbody>
            {rows.map((row, rowIndex) => (
              <tr key={`row-${rowIndex}`}>
                {row.map((cell, colIndex) => (
                  <td
                    key={`cell-${rowIndex}-${colIndex}`}
                    className={colIndex === indexColumnIndex ? 'sticky-col' : undefined}
                    style={{ width: columns[colIndex]?.width }}
                  >
                    {colIndex === indexColumnIndex ? (
                      <span className="index-cell">{cell}</span>
                    ) : (
                      <input
                        type="text"
                        value={cell}
                        onChange={(event) => updateCell(rowIndex, colIndex, event.target.value)}
                        title={cell}
                      />
                    )}
                  </td>
                ))}
                <td className="action-col">
                  <button
                    className="icon-btn danger"
                    type="button"
                    onClick={() => removeRow(rowIndex)}
                    disabled={rows.length <= 1}
                    aria-label={t('deleteRow')}
                    title={t('deleteRow')}
                  >
                    x
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
