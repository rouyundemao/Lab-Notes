import { useEffect, useState } from 'react';

export default function RecordEditModal({ isOpen, record, onClose, onSave, onDelete, t }) {
  const [draft, setDraft] = useState(record);

  useEffect(() => {
    if (!isOpen) return;
    setDraft(record);
  }, [isOpen, record]);

  if (!isOpen || !record) return null;

  const handleChange = (key, value) => {
    setDraft((prev) => ({ ...prev, [key]: value }));
  };

  const handleSave = () => {
    onSave?.(draft);
    onClose();
  };

  const handleDelete = () => {
    onDelete?.(record.id);
    onClose();
  };

  return (
    <div className="modal-backdrop" onClick={onClose} role="presentation">
      <div className="modal-card" onClick={(event) => event.stopPropagation()}>
        <header className="modal-header">
          <h2>{t('editRecordTitle')}</h2>
          <p>{t('editRecordDesc')}</p>
        </header>
        <div className="modal-body">
          <div className="form-grid">
            <label className="field">
              <span>{t('experimentName')}</span>
              <input
                type="text"
                value={draft.name}
                onChange={(event) => handleChange('name', event.target.value)}
              />
            </label>
            <label className="field">
              <span>{t('date')}</span>
              <input
                type="date"
                value={draft.date}
                onChange={(event) => handleChange('date', event.target.value)}
              />
            </label>
            <label className="field">
              <span>{t('researcher')}</span>
              <input
                type="text"
                value={draft.person}
                onChange={(event) => handleChange('person', event.target.value)}
              />
            </label>
            <label className="field span-2">
              <span>{t('objective')}</span>
              <textarea
                rows="2"
                value={draft.purpose}
                onChange={(event) => handleChange('purpose', event.target.value)}
              />
            </label>
          </div>
        </div>
        <div className="modal-actions">
          <button className="btn ghost" type="button" onClick={onClose}>
            {t('cancel')}
          </button>
          <button className="btn danger" type="button" onClick={handleDelete}>
            {t('deleteRecord')}
          </button>
          <button className="btn primary" type="button" onClick={handleSave}>
            {t('saveChanges')}
          </button>
        </div>
      </div>
    </div>
  );
}
